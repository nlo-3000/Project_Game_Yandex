x = 10
y = 30


import os
import pygame


os.environ['SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (x,y)

pygame.init()
pygame.key.set_repeat(200, 70)

FPS = 30
WIDTH = 1200
HEIGHT = 600
STEP = 10

screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

player = None
camera = None
all_sprites = pygame.sprite.Group()
tiles_group = pygame.sprite.Group()
player_group = pygame.sprite.Group()
grasses = []
boxes = []
chests = []
mobs = []


def load_image(name, color_key=None):
    fullname = os.path.join('data_1', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)
        
    #image = image.convert_alpha()
 
    if color_key is not None:
        if color_key == -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    return image
 
def load_level(filename):
    filename = "data_1/" + filename
    with open(filename, 'r') as mapFile:
        level_map = [line.strip() for line in mapFile]
   
    max_width = max(map(len, level_map))
   
    return list(map(lambda x: x.ljust(max_width, '.'), level_map))    

def generate_level(level):
    new_player, x, y = None, None, None
    for y in range(len(level)):
        for x in range(len(level[y])):
            if level[y][x] == '.':
                Tile('empty', x, y)
                grasses.append(Tile('empty', x, y))
                
            elif level[y][x] == '#':
                Tile('middle_tree', x, y)
                boxes.append(Tile('middle_tree', x, y))
            
            elif level[y][x] == '1':
                Tile('fence_corner_left_up', x, y)
                boxes.append(Tile('fence_corner_left_up', x, y))
                
            elif level[y][x] == '2':
                Tile('fence_corner_right_up', x, y)
                boxes.append(Tile('fence_corner_right_up', x, y))
                
            elif level[y][x] == '3':
                Tile('fence_corner_right_down', x, y)
                boxes.append(Tile('fence_corner_right_down', x, y))
                
            elif level[y][x] == '4':
                Tile('fence_corner_left_down', x, y)
                boxes.append(Tile('fence_corner_left_down', x, y))
                
            elif level[y][x] == '-':
                Tile('fence_horizontal', x, y)
                boxes.append(Tile('fence_horizontal', x, y))
                
            elif level[y][x] == '|':
                Tile('fence_vertical_left', x, y)
                boxes.append(Tile('fence_vertical_left', x, y))
                
            elif level[y][x] == '0':
                Tile('fence_vertical_right', x, y)
                boxes.append(Tile('fence_vertical_right', x, y))
                
            elif level[y][x] == '^':
                Tile('chest_1_1', x, y)
                boxes.append(Tile('chest_1_1', x, y))
                
            elif level[y][x] == 'M':
                Tile('bat_down_1', x, y)
                boxes.append(Tile('bat_down_1', x, y))
                
            elif level[y][x] == 'T':
                Tile('big_tree_1', x, y)
                boxes.append(Tile('big_tree_1', x, y))
                
            elif level[y][x] == 'y':
                Tile('middle_trees', x, y)
                boxes.append(Tile('middle_trees', x, y))
                
            elif level[y][x] == '/':
                Tile('wood', x, y)
                boxes.append(Tile('wood', x, y))
                
            elif level[y][x] == 'w':
                Tile('white_flowers', x, y)
                boxes.append(Tile('white_flowers', x, y))
                
            elif level[y][x] == 'E':
                Tile('Exit', x, y)
                boxes.append(Tile('Exit', x, y))
                
            elif level[y][x] == 'r':
                Tile('red_flowers', x, y)
                boxes.append(Tile('red_flowers', x, y))
                
            elif level[y][x] == '@':
                Tile('empty', x, y)
                grasses.append(Tile('empty', x, y))
                new_player = Player(x, y)
                
    return new_player, x, y
 
def terminate():
    pygame.quit()
   # sys.exit()
 
def start_screen():
    fon = pygame.transform.scale(load_image('Foner.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
 
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif (event.type == pygame.MOUSEBUTTONDOWN and event.pos[0] >= 496
                  and event.pos[0] <= 675 and event.pos[1] >= 259 and
                  event.pos[1] <= 328):
                return
            elif (event.type == pygame.MOUSEBUTTONDOWN and event.pos[0] >= 0
                  and event.pos[0] <= 200 and event.pos[1] >= 0 and
                  event.pos[1] <= 80):
                terminate()
            elif (event.type == pygame.MOUSEBUTTONDOWN and event.pos[0] >= 1118
                  and event.pos[0] <= 1200 and event.pos[1] >= 540 and
                  event.pos[1] <= 600):
                shop_screen()
            elif (event.type == pygame.MOUSEBUTTONDOWN and event.pos[0] >= 440
                  and event.pos[0] <= 740 and event.pos[1] >= 150 and
                  event.pos[1] <= 230):
                rules_screen()
                
        pygame.display.flip()
        
        clock.tick(FPS)
        
def win_screen():
    global player, boxes, grasses, all_sprites, tiles_group, player_group
    fon = pygame.transform.scale(load_image('win.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
 
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                player = None
                
                boxes = []
                grasses = []
                all_sprites = pygame.sprite.Group()
                tiles_group = pygame.sprite.Group()
                player_group = pygame.sprite.Group()
                
                start_screen()
                camera, player = level_screen()
                return
                
        pygame.display.flip()
        
        clock.tick(FPS)

def die_screen():
    global player, boxes, grasses, all_sprites, tiles_group, player_group
    fon = pygame.transform.scale(load_image('end_fon.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
 
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                player = None
                
                boxes = []
                grasses = []
                all_sprites = pygame.sprite.Group()
                tiles_group = pygame.sprite.Group()
                player_group = pygame.sprite.Group()
                
                start_screen()
                camera, player = level_screen()
                return
                
        pygame.display.flip()
        
        clock.tick(FPS)
        
def rules_screen():
    fon = pygame.transform.scale(load_image('rules.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
 
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                start_screen()
                return
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    start_screen()
                    return
                
        pygame.display.flip()
        
        clock.tick(FPS)

money = 0

def shop_screen():
    global STEP, money
    fon = pygame.transform.scale(load_image('shop_fon.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
 
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
                
            elif (event.type == pygame.MOUSEBUTTONDOWN and event.pos[0] >= 85
                  and event.pos[0] <= 208 and event.pos[1] >= 122 and
                  event.pos[1] <= 376):
                if money > 0:
                    money -= 1
                    STEP += 1

            elif (event.type == pygame.MOUSEBUTTONDOWN and event.pos[0] >= 893
                  and event.pos[0] <= 1014 and event.pos[1] >= 122 and
                  event.pos[1] <= 376):
                if money > 0:
                    money -= 1
                    STEP -= 1
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    start_screen()
                    return
                
        pygame.display.flip()
        
        clock.tick(FPS)

def level_screen():
    fon = pygame.transform.scale(load_image('forest_fon_1.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
 
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
                
            elif (event.type == pygame.MOUSEBUTTONDOWN and event.pos[0] >= 183
                  and event.pos[0] <= 382 and event.pos[1] >= 210 and
                  event.pos[1] <= 310):
                player, level_x, level_y = generate_level(load_level("level_down_1.txt"))
                player, level_x, level_y = generate_level(load_level("level_up_1.txt"))

                camera = Camera((level_x, level_y))
                return camera, player

            elif (event.type == pygame.MOUSEBUTTONDOWN and event.pos[0] >= 484
                  and event.pos[0] <= 684 and event.pos[1] >= 210 and
                  event.pos[1] <= 310):
                player, level_x, level_y = generate_level(load_level("level_down_1.txt"))
                player, level_x, level_y = generate_level(load_level("level_up_2.txt"))

                camera = Camera((level_x, level_y))
                return camera, player
            
            elif (event.type == pygame.MOUSEBUTTONDOWN and event.pos[0] >= 770
                  and event.pos[0] <= 969 and event.pos[1] >= 210 and
                  event.pos[1] <= 310):
                player, level_x, level_y = generate_level(load_level("level_down_1.txt"))
                player, level_x, level_y = generate_level(load_level("level_up_3.txt"))

                camera = Camera((level_x, level_y))
                return camera, player
                
        pygame.display.flip()
        
        clock.tick(FPS)
 
tile_images = {'empty': load_image('grass.png'), 
               'middle_tree': load_image('middle_tree.png', -1),
               'fence_corner_left_up': load_image('fence_corner_left_up.png', -1), 
               'fence_corner_left_down': load_image('fence_corner_left_down.png', -1), 
               'fence_corner_right_up': load_image('fence_corner_right_up.png', -1),
               'fence_corner_right_down': load_image('fence_corner_right_down.png', -1), 
               'fence_horizontal': load_image('fence_horizontal.png', -1),
               'fence_vertical_left': load_image('fence_vertical_left.png', -1),
               'fence_vertical_right': load_image('fence_vertical_right.png', -1), 
               
               'chest_1_1': load_image('chest_1_1.png', -1), 
               
               'big_tree_1': load_image('big_tree_1.png', -1),
               'middle_trees': load_image('middle_trees.png', -1),
               'wood': load_image('wood.png', -1),
               'white_flowers': load_image('white_flowers.png', -1),
               'Exit': load_image('Exit.png', -1),
               'red_flowers': load_image('red_flowers.png', -1),
               
               'bat_down_1': load_image('mushrooms.png', -1)}

#       player_image = load_image('Deth_weapon_down_2.png', -1)
 
tile_width = tile_height = 40
 
class Tile(pygame.sprite.Sprite):
    def __init__(self, tile_type, pos_x, pos_y):
        super().__init__(tiles_group, all_sprites)
        self.pos_x = pos_x
        self.image = tile_images[tile_type]
        self.rect = self.image.get_rect().move(tile_width * pos_x, tile_height * pos_y)
        
        self.tile = tile_type
        


player_go_right = {'1': load_image('Deth_weapon_right_1.png', -1),
                  '2': load_image('Deth_weapon_right_2.png', -1),
                  '3': load_image('Deth_weapon_right_3.png', -1),
                  '4': load_image('Deth_weapon_right_4.png', -1)}

player_go_left = {'1': load_image('Deth_weapon_left_1.png', -1),
                  '2': load_image('Deth_weapon_left_2.png', -1),
                  '3': load_image('Deth_weapon_left_3.png', -1),
                  '4': load_image('Deth_weapon_left_4.png', -1)}

player_go_up = {'1': load_image('Deth_weapon_up_1.png', -1),
                '2': load_image('Deth_weapon_up_2.png', -1),
                '3': load_image('Deth_weapon_up_3.png', -1),
                '4': load_image('Deth_weapon_up_4.png', -1)}

player_go_down = {'1': load_image('Deth_weapon_down_1.png', -1),
                  '2': load_image('Deth_weapon_down_2.png', -1),
                  '3': load_image('Deth_weapon_down_3.png', -1),
                  '4': load_image('Deth_weapon_down_4.png', -1)}

player_image = player_go_down['1']

 
class Player(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(player_group, all_sprites)
        self.image = player_image
        
        self.pos_x = pos_x
        self.pos = self.rect = self.image.get_rect().move(
            tile_width * pos_x + 15, tile_height * pos_y + 5)
        self.rect = self.rect.move(pos_x, pos_y)

        self.mask = pygame.mask.from_surface(self.image)

        
    def updating(self, diction):
        if flag == 1:
            self.image = diction['1']
        elif flag == 2:
            self.image = diction['2']
        elif flag == 3:
            self.image = diction['3']
        elif flag == 4:
            self.image = diction['4']

        
class Camera:
    def __init__(self, field_size):
        self.dx = 0
        self.dy = 0
        self.field_size = field_size
 
    def apply(self, obj):
        obj.rect.x += self.dx
        if obj.rect.x < -obj.rect.width:
            obj.rect.x += (self.field_size[0] + 1) * obj.rect.width          
        if obj.rect.x >= (self.field_size[0]) * obj.rect.width:
            obj.rect.x += -obj.rect.width * (1 + self.field_size[0])
        obj.rect.y += self.dy
        if obj.rect.y < -obj.rect.height:
            obj.rect.y += (self.field_size[1] + 1) * obj.rect.height
        if obj.rect.y >= (self.field_size[1]) * obj.rect.height:
            obj.rect.y += -obj.rect.height * (1 + self.field_size[1])
 
    def update(self, target):
        self.dx = -(target.rect.x + target.rect.w // 2 - WIDTH // 2)
        self.dy = -(target.rect.y + target.rect.h // 2 - HEIGHT // 2)
 

money = 0

def a(player, boxess):
    global money, boxes, grasses, all_sprites, tiles_group, player_group
    for i in boxess:
        if pygame.sprite.collide_mask(player, i):
            if i.tile == 'chest_1_1':
                i.image = load_image('grass.png')
                money += 1
            if i.tile == 'bat_down_1':
                player = None
                
                boxes = []
                grasses = []
                all_sprites = pygame.sprite.Group()
                tiles_group = pygame.sprite.Group()
                player_group = pygame.sprite.Group()
                i.image = load_image('grass.png')
                die_screen()
            if i.tile == 'Exit':
                player = None
                
                boxes = []
                grasses = []
                all_sprites = pygame.sprite.Group()
                tiles_group = pygame.sprite.Group()
                player_group = pygame.sprite.Group()
                win_screen()

            return True

start_screen()

camera, player = level_screen()

l = 0
r = 0
u = 0
d = 0
dic = player_go_down
flag = 0

pygame.mixer.init()
pygame.mixer.music.load('music.mp3')
pygame.mixer.music.play(-1)
 
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
                
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                player = None
                
                boxes = []
                grasses = []
                all_sprites = pygame.sprite.Group()
                tiles_group = pygame.sprite.Group()
                player_group = pygame.sprite.Group()
                
                start_screen()
                
                camera, player = level_screen()
                
            if event.key == pygame.K_LEFT:
                l = 1
                r = 0
                d = 0
                u = 0
               # player.pos[0] -= 1 # замедление шага при столкновении с определённым спрайтом!!!!!!!!!!
                player.rect.x -= STEP
                if not a(player, boxes):
                    player.rect.x -= STEP
                player.rect.x += STEP
                
            if event.key == pygame.K_RIGHT:
                l = 0
                r = 1
                d = 0
                u = 0
                
                player.rect.x += STEP
                if not a(player, boxes):
                    player.rect.x += STEP
                        
                player.rect.x -= STEP
                
            if event.key == pygame.K_UP:
                l = 0
                r = 0
                d = 0
                u = 1
                
                player.rect.y -= STEP
                if not a(player, boxes):
                    player.rect.y -= STEP
                player.rect.y += STEP
                
            if event.key == pygame.K_DOWN:
                l = 0
                r = 0
                d = 1
                u = 0
                
                player.rect.y += STEP
                if not a(player, boxes):
                    player.rect.y += STEP
                player.rect.y -= STEP
                
        if l == 1:
            dic = player_go_left
        elif r == 1:
            dic = player_go_right
        elif u == 1:
            dic = player_go_up
        elif d == 1:
            dic = player_go_down
        
        flag += 1
        if flag > 4:
            flag = 0
        player.updating(dic)
                

    camera.update(player)
 
    for sprite in all_sprites:
        camera.apply(sprite)
 
    #screen.fill(pygame.Color(0, 0, 0))
    tiles_group.draw(screen)
    player_group.draw(screen)
 
    pygame.display.flip()
 
    clock.tick(FPS)
 
terminate()
